import { UserGroupIcon, LightBulbIcon, ShieldCheckIcon, RocketLaunchIcon } from '@heroicons/react/24/outline';
import Image from 'next/image';

const values = [
  {
    name: 'Innovation Excellence',
    description: 'We pursue cutting-edge solutions and embrace emerging technologies to deliver superiors results.',
    icon: LightBulbIcon,
  },
  {
    name: 'Security First',
    description: 'Every solution is built with security and data protection as fundamental design principles.',
    icon: ShieldCheckIcon,
  },
  {
    name: 'Client Success',
    description: 'Your success drives our mission. We deliver measurable value and sustainable growth.',
    icon: RocketLaunchIcon,
  },
  {
    name: 'Expert Team',
    description: 'Our experienced professionals bring deep expertise across multiple technology domains.',
    icon: UserGroupIcon,
  },
];

const team = [
  {
    name: 'Abhishek Kumar',
    role: 'CEO & Founder',
    expertise: 'AI, Cloud Computing, IT Strategy',
    experience: '10+ years',
  },
  {
    name: 'Salony Pandey',
    role: 'Project Manager',
    expertise: 'Agile, DevOps, Client Relations',
    experience: '4+ years',

  },
  {
    name: ' Amit Kumar',
    role: 'Full Stack Developer',
    expertise: 'Backend, Frontend, DevOps',
    experience: '3+ years',
  },
  {
    name: 'Aachal Priya',
    role: 'Web Developer',
    expertise: 'Frontend, UI/UX Design Mobile Apps',
    experience: ' 2 years',
  },
];

const stats = [
  { label: 'Projects Delivered', value: '18+' },
  { label: 'Client Satisfaction', value: '90%' },
  { label: 'Technologies', value: '25+' },
  { label: 'Years Experience', value: '3+' },
];

export default function AboutPage() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 overflow-hidden min-h-[450px] lg:min-h-[400px]">
        {/* Background Image - Full Hero */}
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/about.png"
            alt="NexyraTech - Transforming Ideas Into Digital Excellence"
            fill
            priority
            className="object-cover object-center opacity-40"
          />
          {/* Overlay gradient for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 via-blue-900/60 to-transparent"></div>
        </div>

        {/* Floating Tech Elements */}
        <div className="absolute inset-0 z-10">
          {/* AI Brain Icon */}
          <div className="absolute top-20 right-20 w-16 h-16 bg-gradient-to-br from-cyan-400/30 to-blue-500/30 rounded-full flex items-center justify-center animate-pulse">
            <div className="w-8 h-8 border-2 border-cyan-400 rounded-full relative">
              <div className="absolute inset-1 border border-cyan-400 rounded-full opacity-60"></div>
            </div>
          </div>

          {/* Chart/Analytics Icons */}
          <div className="absolute top-40 right-40 w-12 h-12 bg-gradient-to-br from-blue-400/20 to-indigo-500/20 rounded-lg rotate-12 flex items-center justify-center">
            <div className="w-6 h-6 border border-blue-400 rounded opacity-70">
              <div className="w-full h-full bg-gradient-to-t from-blue-400/40 to-transparent rounded"></div>
            </div>
          </div>

          {/* Code/Development Icon */}
          <div className="absolute bottom-32 right-32 w-10 h-10 bg-gradient-to-br from-purple-400/20 to-pink-500/20 rounded-md -rotate-12 flex items-center justify-center">
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-ping"></div>
          </div>

          {/* Network/Connection Lines */}
          <div className="absolute top-1/3 right-1/4 w-24 h-px bg-gradient-to-r from-transparent via-cyan-400/40 to-transparent transform rotate-45"></div>
          <div className="absolute bottom-1/3 right-1/3 w-20 h-px bg-gradient-to-r from-transparent via-blue-400/30 to-transparent transform -rotate-12"></div>

          {/* Floating Particles */}
          <div className="absolute top-1/4 right-1/5 w-2 h-2 bg-cyan-400 rounded-full animate-bounce opacity-60"></div>
          <div className="absolute bottom-1/4 right-1/6 w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse opacity-50"></div>
          <div className="absolute top-2/3 right-1/4 w-1 h-1 bg-purple-400 rounded-full animate-ping opacity-40"></div>

          {/* Grid Pattern Overlay */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(99, 179, 237, 0.4) 1px, transparent 0)',
              backgroundSize: '50px 50px'
            }}></div>
          </div>
        </div>

        {/* Content Container */}
        <div className="container-custom py-12 md:py-16 relative z-20">
          <div className="max-w-4xl">
            {/* Badge */}
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-blue-500/10 backdrop-blur-sm border border-blue-400/30 text-blue-300 text-sm font-medium mb-6">
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse mr-3"></span>
              Learn About Our Journey
            </div>

            {/* Main Heading */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white leading-tight mb-6">
              Transforming Ideas Into
              <span className="block bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                Digital Excellence
              </span>
            </h1>

            {/* Description */}
            <p className="text-lg lg:text-xl text-blue-100/90 leading-relaxed mb-8 max-w-2xl">
              We are a forward-thinking IT solutions company dedicated to transforming businesses 
              through innovative technology and cutting-edge research & development.
            </p>

            {/* Feature Tags */}
            <div className="flex flex-wrap gap-4">
              <div className="inline-flex items-center px-4 py-2 bg-cyan-500/10 backdrop-blur-sm border border-cyan-400/30 rounded-lg text-cyan-400 text-sm font-medium">
                <RocketLaunchIcon className="w-4 h-4 mr-2" />
                Innovation Driven
              </div>
              <div className="inline-flex items-center px-4 py-2 bg-blue-500/10 backdrop-blur-sm border border-blue-400/30 rounded-lg text-blue-400 text-sm font-medium">
                <ShieldCheckIcon className="w-4 h-4 mr-2" />
                Security First
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Gradient Fade */}
        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white to-transparent z-15"></div>
      </section>

      {/* Company Overview */}
      <section className="relative bg-white">
        <div className="container-custom py-8 md:py-10">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-8 items-center">
            {/* Mission */}
            <div className="relative">
              <div className="absolute top-0 left-0 w-12 h-12 bg-gradient-to-br from-cyan-500/10 to-blue-600/10 rounded-xl transform -rotate-6"></div>
              <div className="relative bg-white p-4 rounded-lg shadow-md border border-gray-100 hover:shadow-lg transition-all duration-300">
                <div className="flex items-center mb-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center mr-2">
                    <LightBulbIcon className="w-4 h-4 text-white" />
                  </div>
                  <h2 className="text-lg font-bold text-gray-900">
                    Our <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Mission</span>
                  </h2>
                </div>

                <div className="space-y-2 text-gray-600 leading-relaxed text-xs">
                  <p>
                    <b>Quality Services</b>
                  </p>
                  <p>
                    Provide high-quality and cost-effective digital services that meet the unique
                    needs of every client we partner with.
                  </p>
                  <p>
                    <b>Business Growth</b>
                  </p>
                  <p>
                    Help startups and established businesses grow their online presence and reach
                    their target audience effectively.
                  </p>
                  <p>
                   <b> Excellence & Trust</b>
                  </p>
                  <p>
                    Deliver projects on time with excellence, ensuring customer satisfaction and
                    building lasting trust with every engagement.
                  </p>
                </div>
              </div>
            </div>

            {/* Vision */}
            <div className="relative">
              <div className="absolute top-0 right-0 w-10 h-10 bg-gradient-to-br from-blue-500/10 to-indigo-600/10 rounded-full transform rotate-12"></div>
              <div className="relative bg-white p-4 rounded-lg shadow-md border border-gray-100 hover:shadow-lg transition-all duration-300">
                <div className="flex items-center mb-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center mr-2">
                    <ShieldCheckIcon className="w-4 h-4 text-white" />
                  </div>
                  <h2 className="text-lg font-bold text-gray-900">
                    Our <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Vision</span>
                  </h2>
                </div>

                <div className="space-y-2 text-gray-600 leading-relaxed text-xs">
                  <p>
                    <b>Innovation Leadership</b>
                  </p>
                  <p>
                    To be the leading technology partner that empowers businesses through cutting-edge digital transformation and innovative solutions.
                  </p>
                  <p>
                    <b>Global Impact</b>
                  </p>
                  <p>
                    Create scalable digital solutions that make a meaningful impact on businesses worldwide, driving growth and success.
                  </p>
                  <p>
                    <b>Technology Excellence</b>
                  </p>
                  <p>
                    Pioneer emerging technologies and set new standards in digital innovation, quality, and client satisfaction.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="relative bg-gradient-to-r from-gray-50 to-blue-50 py-8 md:py-10">
        <div className="container-custom">
          <div className="text-center mb-8">
            <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">
              Why <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Choose Us</span>
            </h2>
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            {/* Professional & Modern Design */}
            <div className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg border border-gray-100 transition-all duration-300">
              <h3 className="text-base font-bold text-gray-900 mb-2">
                Professional & Modern Design
              </h3>
              <p className="text-gray-600 leading-relaxed text-xs">
                We create sleek, contemporary designs that elevate your brand image. Our 100% 
                responsive solutions ensure your digital presence looks perfect on every device.
              </p>
            </div>

            {/* Affordable & Fast Delivery */}
            <div className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg border border-gray-100 transition-all duration-300">
              <h3 className="text-base font-bold text-gray-900 mb-2">
                Affordable & Fast Delivery
              </h3>
              <p className="text-gray-600 leading-relaxed text-xs">
                Get premium quality digital services at competitive prices. We pride ourselves on 
                delivering projects on time without compromising on excellence.
              </p>
            </div>

            {/* 24/7 Support & Satisfaction */}
            <div className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg border border-gray-100 transition-all duration-300">
              <h3 className="text-base font-bold text-gray-900 mb-2">
                24/7 Support & Satisfaction
              </h3>
              <p className="text-gray-600 leading-relaxed text-xs">
                Round-the-clock support ensures you&apos;re never alone. Our client-first approach 
                means your satisfaction is our top priority. &quot;We deliver quality, not just code.&quot;
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative bg-gradient-to-r from-cyan-50 to-blue-50 py-8">
        <div className="container-custom">
          <div className="text-center mb-6">
            <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">
              Our <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Achievements</span>
            </h2>
            <p className="text-gray-600 max-w-xl mx-auto text-xs">Numbers that reflect our commitment to excellence and client success</p>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center group">
                <div className="relative">
                  <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg mx-auto mb-2 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-md">
                    <span className="text-white font-bold text-sm">{stat.value}</span>
                  </div>
                  <div className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
                </div>
                <p className="text-gray-700 font-medium text-xs">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="relative bg-white">
        <div className="container-custom py-8 md:py-10">
          <div className="text-center mb-8">
            <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">
              Our Core <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Values</span>
            </h2>
            <p className="text-xs text-gray-600 max-w-2xl mx-auto">
              The principles that guide our work and define our culture of excellence and innovation.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((value) => (
              <div key={value.name} className="group relative">
                <div className="relative bg-white p-4 rounded-lg shadow-md hover:shadow-lg border border-gray-100 transition-all duration-300 text-center h-full">
                  {/* Floating icon background */}
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-md">
                      <value.icon className="h-4 w-4 text-white" />
                    </div>
                  </div>

                  <div className="mt-5">
                    <h3 className="text-sm font-semibold text-gray-900 mb-2 group-hover:text-cyan-600 transition-colors">
                      {value.name}
                    </h3>
                    <p className="text-gray-600 leading-relaxed text-xs">
                      {value.description}
                    </p>
                  </div>

                  {/* Decorative element */}
                  <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-b-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="relative bg-gradient-to-r from-slate-50 to-blue-50">
        <div className="container-custom py-8 md:py-10">
          <div className="text-center mb-8">
            <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">
              Our Expert <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Team</span>
            </h2>
            <p className="text-xs text-gray-600 max-w-2xl mx-auto">
              Meet the passionate professionals driving innovation and delivering exceptional results for our clients.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {team.map((member) => (
              <div key={member.name} className="group relative">
                <div className="bg-white p-3 rounded-lg shadow-md hover:shadow-lg border border-gray-100 transition-all duration-300 text-center h-40 flex flex-col">
                  {/* Avatar */}
                  <div className="relative mb-2">
                    <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg mx-auto flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-md">
                      <span className="text-white font-bold text-xs">
                        {member.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-400 rounded-full border-2 border-white flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  </div>

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xs font-semibold text-gray-900 group-hover:text-cyan-600 transition-colors mb-1 line-clamp-1">
                        {member.name}
                      </h3>
                      <p className="text-cyan-600 font-medium mb-1 text-xs">{member.role}</p>
                      <p className="text-xs text-gray-600 mb-1 line-clamp-2 leading-tight">{member.expertise}</p>
                    </div>
                    <div className="mt-auto">
                      <div className="inline-flex items-center px-2 py-0.5 bg-gradient-to-r from-cyan-100 to-blue-100 rounded-full">
                        <span className="text-xs text-cyan-700 font-medium">{member.experience}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}