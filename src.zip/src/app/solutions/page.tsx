import Link from 'next/link';
import { 
  CodeBracketIcon, 
  DevicePhoneMobileIcon, 
  ComputerDesktopIcon, 
  CloudIcon,
  ShieldCheckIcon,
  CpuChipIcon,
  BoltIcon,
  CogIcon,
  ArrowRightIcon,
  SparklesIcon
} from '@heroicons/react/24/outline';

const solutions = [
  {
    id: 'web-development',
    name: 'Web Development',
    description: 'Full-stack web applications using modern frameworks and technologies for optimal performance and user experience.',
    icon: CodeBracketIcon,
    technologies: ['Next.js', 'React', 'Node.js', 'MongoDB', 'PostgreSQL','Spring Boot', 'sql'],
    features: [
      'Responsive design and mobile optimization',
      'Progressive Web Applications (PWA)',
      'E-commerce and content management systems',
      'API development and integration',
      'Performance optimization and SEO',
    ],
  },
  {
    id: 'mobile-development',
    name: 'Mobile App Development', 
    description: 'Native and cross-platform mobile applications that deliver exceptional user experiences across all devices.',
    icon: DevicePhoneMobileIcon,
    technologies: ['React Native', 'Flutter', 'Swift', 'Kotlin', 'Xamarin'],
    features: [
      'iOS and Android native development',
      'Cross-platform hybrid solutions',
      'Mobile UI/UX design and optimization',
      'App store deployment and maintenance',
      'Push notifications and offline functionality',
    ],
  },
  {
    id: 'desktop-applications',
    name: 'Desktop Applications',
    description: 'Robust desktop software solutions for Windows, macOS, and Linux platforms with advanced functionality.',
    icon: ComputerDesktopIcon,
    technologies: ['Electron', '.NET', 'Java', 'Python', 'C++'],
    features: [
      'Cross-platform compatibility',
      'Rich user interfaces and advanced features',
      'Database integration and data management',
      'System integration and automation tools',
      'Enterprise-grade security and performance',
    ],
  },
  {
    id: 'cloud-solutions',
    name: 'Cloud Solutions',
    description: 'Scalable cloud infrastructure and migration services using leading cloud platforms and DevOps practices.',
    icon: CloudIcon,
    technologies: ['Hostinger','AWS', 'Azure',  'Docker', 'Kubernetes'],
    features: [
      'Cloud migration and modernization',
      'Serverless architecture and microservices',
      'Container orchestration and management',
      'Auto-scaling and load balancing',
      'Cost optimization and monitoring',
    ],
  },
  {
    id: 'cybersecurity',
    name: 'Cybersecurity Solutions',
    description: 'Comprehensive security solutions to protect your digital assets, data, and infrastructure from threats.',
    icon: ShieldCheckIcon,
    technologies: ['Penetration Testing', 'SIEM', 'Zero Trust', 'Blockchain Security'],
    features: [
      'Security audits and penetration testing',
      'Data encryption and secure communication',
      'Identity and access management (IAM)',
      'Incident response and recovery planning',
      'Compliance and regulatory adherence',
    ],
  },
  {
    id: 'iot-solutions',
    name: 'IoT Solutions',
    description: 'Internet of Things implementations connecting devices, sensors, and systems for intelligent automation.',
    icon: CpuChipIcon,
    technologies: ['Arduino', 'Raspberry Pi', 'MQTT', 'LoRaWAN', 'Edge Computing'],
    features: [
      'Sensor networks and device connectivity',
      'Real-time data collection and analytics',
      'Industrial automation and monitoring',
      'Smart home and building solutions',
      'Predictive maintenance systems',
    ],
  },
  {
    id: 'ai-ml-solutions',
    name: 'AI & Machine Learning',
    description: 'Artificial intelligence and machine learning solutions to automate processes and generate insights.',
    icon: BoltIcon,
    technologies: ['TensorFlow', 'PyTorch', 'scikit-learn', 'OpenAI', 'Computer Vision'],
    features: [
      'Predictive analytics and forecasting',
      'Natural language processing (NLP)',
      'Computer vision and image recognition',
      'Recommendation systems and personalization',
      'Automated decision-making systems',
    ],
  },
  {
    id: 'system-integration',
    name: 'System Integration',
    description: 'Seamless integration of disparate systems, applications, and data sources for unified operations.',
    icon: CogIcon,
    technologies: ['REST APIs', 'GraphQL', 'ETL', 'Message Queues', 'Enterprise Service Bus'],
    features: [
      'Legacy system modernization',
      'API development and management',
      'Data synchronization and migration',
      'Workflow automation and optimization',
      'Real-time integration and monitoring',
    ],
  },
];

const processSteps = [
  {
    step: '01',
    title: 'Discovery & Planning',
    description: 'We analyze your requirements, assess technical feasibility, and create a comprehensive project roadmap.',
  },
  {
    step: '02', 
    title: 'Design & Architecture',
    description: 'Our experts design scalable architectures and create detailed technical specifications for your solution.',
  },
  {
    step: '03',
    title: 'Development & Testing',
    description: 'Agile development with continuous testing, code reviews, and quality assurance throughout the process.',
  },
  {
    step: '04',
    title: 'Deployment & Support',
    description: 'Seamless deployment to production environments with ongoing support, maintenance, and optimization.',
  },
];

export default function SolutionsPage() {
  return (
    <div className="bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-100 min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 to-cyan-600 overflow-hidden">
        {/* Simple Background Elements */}
        <div className="absolute inset-0 z-0">
          {/* Subtle Gradient Orbs */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-400/10 rounded-full blur-2xl"></div>
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-blue-400/8 rounded-full blur-xl"></div>
          
          {/* Simple Grid Pattern */}
          <div className="absolute inset-0 opacity-3">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255, 255, 255, 0.2) 1px, transparent 0)',
              backgroundSize: '40px 40px'
            }}></div>
          </div>
        </div>

        {/* Content */}
        <div className="container-custom py-8 md:py-10 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            {/* Simple Badge */}
            <div className="inline-flex items-center px-3 py-1 bg-white/15 rounded-full text-white text-xs font-medium mb-4">
              <SparklesIcon className="w-3 h-3 mr-2" />
              Technology Solutions
            </div>

            {/* Main Heading */}
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white leading-tight mb-3">
              IT Solutions &
              <span className="block text-cyan-200"> Services</span>
            </h1>

            {/* Description */}
            <p className="text-sm lg:text-base text-blue-100 leading-relaxed max-w-2xl mx-auto mb-6">
              Comprehensive technology solutions tailored to meet your business objectives 
              and drive digital transformation across your organization.
            </p>

            {/* Simple Service Icons */}
            <div className="flex justify-center items-center gap-3 mb-6">
              <div className="flex items-center space-x-1 bg-white/10 px-3 py-1 rounded-md">
                <CodeBracketIcon className="w-4 h-4 text-cyan-300" />
                <span className="text-white text-xs">Web</span>
              </div>
              
              <div className="flex items-center space-x-1 bg-white/10 px-3 py-1 rounded-md">
                <DevicePhoneMobileIcon className="w-4 h-4 text-blue-300" />
                <span className="text-white text-xs">Mobile</span>
              </div>
              
              <div className="flex items-center space-x-1 bg-white/10 px-3 py-1 rounded-md">
                <CloudIcon className="w-4 h-4 text-cyan-300" />
                <span className="text-white text-xs">Cloud</span>
              </div>
            </div>

            {/* Simple CTA */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button className="inline-flex items-center px-5 py-2 bg-white/20 border border-white/30 rounded-md text-white text-sm font-medium hover:bg-white/30 transition-all duration-300">
                <span>View Solutions</span>
                <ArrowRightIcon className="w-3 h-3 ml-2" />
              </button>

              <div className="text-cyan-200 text-xs">
                7+ Service Categories
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Solutions Grid */}
      <section className="relative">
        <div className="container-custom py-4 md:py-6">
          <div className="grid gap-4 lg:grid-cols-2">
            {solutions.map((solution) => (
              <div key={solution.id} className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-md opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
                <div className="relative p-3 rounded-md bg-white shadow-lg hover:shadow-xl transition-all duration-300 border-l-3 border-cyan-400">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-cyan-500 to-blue-600 group-hover:scale-110 transition-transform duration-300">
                        <solution.icon className="h-4 w-4 text-white" aria-hidden="true" />
                      </div>
                    </div>
                    <div className="ml-3 flex-1">
                      <h3 className="text-base font-semibold text-gray-800 mb-1 group-hover:text-cyan-600 transition-colors">{solution.name}</h3>
                      <p className="text-xs text-gray-600 mb-3 leading-tight">{solution.description}</p>
                      
                      {/* Technologies */}
                      <div className="mb-3">
                        <h4 className="text-xs font-medium text-gray-700 mb-1">Technologies:</h4>
                        <div className="flex flex-wrap gap-1">
                          {solution.technologies.map((tech, techIndex) => (
                            <span
                              key={techIndex}
                              className="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-cyan-100 text-cyan-700"
                            >
                              {tech}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      {/* Features */}
                      <div>
                        <h4 className="text-xs font-medium text-gray-700 mb-1">Key Features:</h4>
                        <ul className="text-xs text-gray-600 space-y-0.5">
                          {solution.features.slice(0, 3).map((feature, featureIndex) => (
                            <li key={featureIndex} className="flex items-start group/item">
                              <div className="flex-shrink-0 w-1 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full mt-1.5 mr-2 group-hover/item:scale-125 transition-transform"></div>
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="bg-gradient-to-r from-cyan-100/50 to-blue-100/50 relative">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 25% 25%, rgba(34, 211, 238, 0.3) 2px, transparent 2px)'
          }}></div>
        </div>
        
        <div className="container-custom py-4 md:py-6 relative">
          <div className="text-center mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">
              Our Development
              <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent"> Process</span>
            </h2>
            <p className="text-sm sm:text-base text-gray-600">
              A proven methodology that ensures successful project delivery.
            </p>
          </div>
          
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {processSteps.map((step, index) => (
              <div key={index} className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-lg opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
                <div className="relative p-4 rounded-lg bg-white shadow-lg hover:shadow-xl transition-all duration-300 text-center border-t-4 border-cyan-400 h-48 flex flex-col">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 text-white rounded-full font-bold text-lg mb-4 group-hover:scale-110 transition-transform duration-300 mx-auto">
                    {step.step}
                  </div>
                  <h3 className="text-base font-semibold text-gray-800 mb-2 group-hover:text-cyan-600 transition-colors">{step.title}</h3>
                  <p className="text-xs text-gray-600 leading-relaxed flex-1">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/10 via-transparent to-blue-500/10"></div>
        
        <div className="container-custom py-4 md:py-6 relative">
          <div className="relative p-6 md:p-8 rounded-lg bg-white shadow-lg text-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-3">
              Ready to Transform Your
              <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent"> Business?</span>
            </h2>
            <p className="text-sm sm:text-base text-gray-600 mb-6 max-w-2xl mx-auto">
              Let our experts analyze your requirements and recommend the best technology 
              solutions for your specific needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link href="/contact" className="group inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg hover:from-cyan-600 hover:to-blue-700 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl">
                Get Free Consultation
              </Link>
              <Link href="/projects?category=it-solutions" className="inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-cyan-600 border-2 border-cyan-400 rounded-lg hover:bg-cyan-50 transition-all duration-300">
                View Our Work
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}