import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import ClientLayout from '@/components/ClientLayout';
import ErrorBoundary from '@/components/ErrorBoundary';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: {
    default: 'NexyraTechSolution - Premier IT Solutions & R&D',
    template: '%s | NexyraTechSolution'
  },
  description: 'Leading IT solutions company specializing in cutting-edge technology development, research & development, and innovative software solutions for enterprises.',
  keywords: ['IT Solutions', 'Software Development', 'Research and Development', 'Technology Consulting', 'Web Development', 'Mobile Apps', 'AI/ML'],
  authors: [{ name: 'NexyraTechSolution' }],
  creator: 'NexyraTechSolution',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://nexyratech.in',
    title: 'NexyraTechSolution - Premier IT Solutions & R&D',
    description: 'Leading IT solutions company specializing in cutting-edge technology development and research.',
    siteName: 'NexyraTechSolution',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'NexyraTechSolution - Premier IT Solutions & R&D',
    description: 'Leading IT solutions company specializing in cutting-edge technology development and research.',
    creator: '@nexyratech',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ErrorBoundary>
          <ClientLayout>
            {children}
          </ClientLayout>
        </ErrorBoundary>
      </body>
    </html>
  );
}