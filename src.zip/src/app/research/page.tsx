'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { CalendarIcon, UserIcon, TagIcon, ChevronDownIcon, ArrowRightIcon } from '@heroicons/react/24/outline';
import { toast } from 'react-hot-toast';

interface ResearchContent {
  _id: string;
  title: string;
  content: string;
  summary: string;
  category: string;
  tags: string[];
  author: string;
  publishedDate: string;
}

interface ResearchResponse {
  research: ResearchContent[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

const categories = [
  { value: '', label: 'All Categories' },
  { value: 'artificial-intelligence', label: 'Artificial Intelligence' },
  { value: 'machine-learning', label: 'Machine Learning' },
  { value: 'blockchain', label: 'Blockchain' },
  { value: 'iot', label: 'Internet of Things' },
  { value: 'cybersecurity', label: 'Cybersecurity' },
  { value: 'cloud-computing', label: 'Cloud Computing' },
  { value: 'other', label: 'Other' },
];

const researchAreas = [
  {
    title: 'Artificial Intelligence & Machine Learning',
    description: 'Advancing AI capabilities through deep learning, neural networks, and intelligent automation systems.',
    highlights: ['Computer Vision', 'Natural Language Processing', 'Predictive Analytics', 'Neural Networks'],
  },
  {
    title: 'Blockchain & Distributed Systems',
    description: 'Exploring decentralized technologies, smart contracts, and distributed ledger applications.',
    highlights: ['Smart Contracts', 'DeFi Protocols', 'Consensus Algorithms', 'Cryptocurrency'],
  },
  {
    title: 'Cybersecurity & Privacy',
    description: 'Developing advanced security solutions and privacy-preserving technologies.',
    highlights: ['Zero Trust Architecture', 'Quantum Cryptography', 'Threat Detection', 'Privacy Engineering'],
  },
  {
    title: 'Internet of Things & Edge Computing',
    description: 'Creating intelligent connected systems and edge processing solutions.',
    highlights: ['Sensor Networks', 'Edge AI', 'Industrial IoT', 'Smart Cities'],
  },
];

export default function ResearchPage() {
  const [research, setResearch] = useState<ResearchContent[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [pagination, setPagination] = useState({
    total: 0,
    page: 1,
    limit: 6,
    totalPages: 0,
  });

  const fetchResearch = useCallback(async (category = '', page = 1) => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: page.toString(),
        limit: pagination.limit.toString(),
      });
      
      if (category) {
        params.append('category', category);
      }
      
      const response = await fetch(`/api/research?${params}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch research');
      }
      
      const data: ResearchResponse = await response.json();
      setResearch(data.research || []);
      setPagination(data.pagination);
    } catch (error) {
      console.error('Error fetching research:', error);
      toast.error('Failed to load research content');
    } finally {
      setLoading(false);
    }
  }, [pagination.limit]);

  useEffect(() => {
    fetchResearch(selectedCategory, 1);
  }, [selectedCategory, fetchResearch]);

  // Handle clicks outside dropdown to close it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    setPagination(prev => ({ ...prev, page: 1 }));
    setIsDropdownOpen(false); // Close dropdown after selection
  };

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const getSelectedCategoryLabel = () => {
    const category = categories.find(cat => cat.value === selectedCategory);
    return category ? category.label : 'All Categories';
  };

  const handlePageChange = (newPage: number) => {
    fetchResearch(selectedCategory, newPage);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className="bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-100 min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-800 to-blue-900 overflow-hidden">
        {/* Simple Background Elements */}
        <div className="absolute inset-0 z-0">
          {/* Subtle Gradient Orbs */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/10 rounded-full blur-2xl"></div>
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-blue-500/8 rounded-full blur-xl"></div>

          {/* Simple Grid Pattern */}
          <div className="absolute inset-0 opacity-3">
            <div className="absolute inset-0" style={{
              backgroundImage: `
                linear-gradient(90deg, rgba(34, 197, 94, 0.08) 1px, transparent 1px),
                linear-gradient(rgba(34, 197, 94, 0.08) 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px'
            }}></div>
          </div>
        </div>

        {/* Content */}
        <div className="container-custom py-8 md:py-10 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            {/* Innovation Badge */}
            <div className="inline-flex items-center px-3 py-1 bg-gradient-to-r from-cyan-500/15 to-purple-500/15 border border-cyan-400/20 rounded-full text-cyan-300 text-xs font-medium mb-4">
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse mr-2"></div>
              <span>Innovation & Research</span>
            </div>

            {/* Main Heading */}
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white leading-tight mb-3">
              Research &
              <span className="block bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                Development
              </span>
            </h1>

            {/* Description */}
            <p className="text-sm lg:text-base text-blue-100/90 leading-relaxed max-w-2xl mx-auto mb-6">
              Pioneering technological innovations through 
              <span className="font-semibold text-cyan-300"> cutting-edge research </span>
              and development in emerging technologies and 
              <span className="font-semibold text-purple-300"> next-generation solutions</span>.
            </p>

            {/* Research Focus Areas */}
            <div className="flex justify-center items-center gap-3 mb-6">
              <div className="flex items-center space-x-1 bg-white/10 px-3 py-1 rounded-md border border-cyan-400/20">
                <div className="w-3 h-3 border border-cyan-400 rounded-full">
                  <div className="w-full h-full bg-cyan-400/30 rounded-full"></div>
                </div>
                <span className="text-cyan-300 text-xs">AI & ML</span>
              </div>

              <div className="flex items-center space-x-1 bg-white/10 px-3 py-1 rounded-md border border-blue-400/20">
                <div className="w-3 h-3 bg-blue-400 rounded-sm"></div>
                <span className="text-blue-300 text-xs">Blockchain</span>
              </div>

              <div className="flex items-center space-x-1 bg-white/10 px-3 py-1 rounded-md border border-purple-400/20">
                <div className="w-3 h-3 border border-purple-400 rounded-full relative">
                  <div className="absolute inset-0.5 border border-purple-400/60 rounded-full"></div>
                </div>
                <span className="text-purple-300 text-xs">IoT</span>
              </div>
            </div>

            {/* CTA Button */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button className="inline-flex items-center px-5 py-2 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-400/30 rounded-md text-white text-sm font-medium hover:from-cyan-500/30 hover:to-purple-500/30 transition-all duration-300">
                <span>Explore Research</span>
                <ArrowRightIcon className="w-3 h-3 ml-2" />
              </button>

              <div className="text-cyan-300 text-xs">
                4 Active Research Areas
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Research Areas */}
      <section className="relative">
        <div className="container-custom py-4 md:py-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">
              Our Research
              <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent"> Focus Areas</span>
            </h2>
            <p className="text-sm sm:text-base text-gray-600">
              Exploring the frontiers of technology to create tomorrow&apos;s solutions.
            </p>
          </div>
          
          <div className="grid gap-6 lg:grid-cols-2">
            {researchAreas.map((area, index) => (
              <div key={index} className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-lg opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
                <div className="relative p-4 md:p-6 rounded-lg bg-white shadow-lg hover:shadow-xl transition-all duration-300 border-l-4 border-cyan-400">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3 group-hover:text-cyan-600 transition-colors">{area.title}</h3>
                  <p className="text-sm text-gray-600 mb-4 leading-relaxed">{area.description}</p>
                  <div className="flex flex-wrap gap-1">
                    {area.highlights.map((highlight, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-cyan-100 text-cyan-700"
                      >
                        {highlight}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Published Research */}
      <section className="bg-gradient-to-r from-cyan-100/50 to-blue-100/50 relative">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 25% 25%, rgba(34, 211, 238, 0.3) 2px, transparent 2px)'
          }}></div>
        </div>
        <div className="container-custom py-4 md:py-6 relative">
          <div className="text-center mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">
              Published
              <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent"> Research</span>
            </h2>
            <p className="text-sm sm:text-base text-gray-600">
              Latest findings and insights from our research initiatives.
            </p>
          </div>
          
          {/* Category Filter */}
          <div className="mb-8">
            <div className="flex justify-center">
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={toggleDropdown}
                  className={`flex items-center justify-between px-6 py-3 min-w-52 text-sm font-medium rounded-full transition-all duration-300 ${
                    selectedCategory === '' 
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg transform scale-105'
                      : 'bg-white text-gray-600 shadow-md hover:shadow-lg hover:bg-cyan-50 border border-gray-200'
                  }`}
                >
                  <span>{getSelectedCategoryLabel()}</span>
                  <ChevronDownIcon className={`ml-2 h-4 w-4 transition-transform duration-200 ${
                    isDropdownOpen ? 'rotate-180' : ''
                  }`} />
                </button>
                
                {/* Dropdown Menu */}
                {isDropdownOpen && (
                  <div className="absolute top-full left-0 mt-2 w-full bg-white rounded-lg shadow-lg border border-gray-200 z-10">
                    <div className="py-2">
                      {categories.map((category) => (
                        <button
                          key={category.value}
                          onClick={() => handleCategoryChange(category.value)}
                          className={`w-full text-left px-4 py-2 text-sm hover:bg-cyan-50 transition-colors ${
                            selectedCategory === category.value
                              ? 'bg-cyan-50 text-cyan-600 font-medium'
                              : 'text-gray-600'
                          }`}
                        >
                          {category.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Individual category buttons (excluding All Categories) */}
            <div className="flex flex-wrap justify-center gap-3 mt-6">
              {categories.slice(1).map((category) => (
                <button
                  key={category.value}
                  onClick={() => handleCategoryChange(category.value)}
                  className={`px-6 py-3 text-sm font-medium rounded-full transition-all duration-300 ${
                    selectedCategory === category.value
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg transform scale-105'
                      : 'bg-white text-gray-600 shadow-md hover:shadow-lg hover:bg-cyan-50 border border-gray-200'
                  }`}
                >
                  {category.label}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-cyan-200 border-t-cyan-500"></div>
            </div>
          ) : !research || research.length === 0 ? (
            <div className="text-center py-12">
              <div className="relative p-6 rounded-lg bg-white shadow-lg">
                <h3 className="text-xl font-semibold text-gray-800 mb-3">No research published yet</h3>
                <p className="text-sm text-gray-600">Check back later for our latest research findings and innovations.</p>
              </div>
            </div>
          ) : (
            <>
              {/* Research Articles Grid */}
              <div className="grid gap-6 lg:grid-cols-2">
                {research.map((article) => (
                  <article key={article._id} className="group relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-lg opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
                    <div className="relative p-4 md:p-6 rounded-lg bg-white shadow-lg hover:shadow-xl transition-all duration-300 border-t-4 border-cyan-400">
                      <div className="flex items-start justify-between mb-3">
                        <h3 className="text-lg font-semibold text-gray-800 line-clamp-2 group-hover:text-cyan-600 transition-colors">
                          {article.title}
                        </h3>
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-cyan-100 text-cyan-700 ml-3 flex-shrink-0">
                          {article.category.replace('-', ' ')}
                        </span>
                      </div>
                      
                      <p className="text-sm text-gray-600 mb-4 line-clamp-3 leading-relaxed">
                        {article.summary}
                      </p>
                      
                      {/* Tags */}
                      {article.tags && article.tags.length > 0 && (
                        <div className="flex items-center mb-3">
                          <TagIcon className="h-4 w-4 text-cyan-500 mr-2" />
                          <div className="flex flex-wrap gap-1">
                            {article.tags.slice(0, 3).map((tag, index) => (
                              <span
                                key={index}
                                className="text-xs text-cyan-700 bg-cyan-50 px-2 py-1 rounded-full border border-cyan-200"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {/* Article Footer */}
                      <div className="flex items-center justify-between pt-4 border-t border-gray-200 text-sm text-gray-500">
                        <div className="flex items-center">
                          <UserIcon className="h-4 w-4 mr-2 text-cyan-500" />
                          <span className="text-gray-700">{article.author}</span>
                        </div>
                        <div className="flex items-center">
                          <CalendarIcon className="h-4 w-4 mr-2 text-cyan-500" />
                          <span>{formatDate(article.publishedDate)}</span>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
              
              {/* Pagination */}
              {pagination.totalPages > 1 && (
                <div className="mt-12 flex items-center justify-center">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handlePageChange(pagination.page - 1)}
                      disabled={pagination.page === 1}
                      className="px-6 py-3 text-sm font-medium text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-cyan-50 hover:border-cyan-300 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                    >
                      Previous
                    </button>
                    
                    {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                      const pageNum = i + 1;
                      return (
                        <button
                          key={pageNum}
                          onClick={() => handlePageChange(pageNum)}
                          className={`px-4 py-3 text-sm font-medium rounded-lg transition-all duration-300 ${
                            pagination.page === pageNum
                              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg transform scale-105'
                              : 'text-gray-600 bg-white border border-gray-300 hover:bg-cyan-50 hover:border-cyan-300 shadow-md'
                          }`}
                        >
                          {pageNum}
                        </button>
                      );
                    })}
                    
                    <button
                      onClick={() => handlePageChange(pagination.page + 1)}
                      disabled={pagination.page === pagination.totalPages}
                      className="px-6 py-3 text-sm font-medium text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-cyan-50 hover:border-cyan-300 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </section>
    </div>
  );
}