'use client';

import Link from 'next/link';
import { 
  EyeIcon, 
  CodeBracketIcon, 
  DevicePhoneMobileIcon, 
  GlobeAltIcon,
  ArrowTopRightOnSquareIcon,
  ClipboardDocumentListIcon,
  ChartBarIcon,
  PaintBrushIcon,
  DocumentTextIcon,
  MagnifyingGlassIcon,
  RocketLaunchIcon,
  WrenchScrewdriverIcon,
  CubeTransparentIcon,
  SparklesIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline';

interface Project {
  id: number;
  name: string;
  description: string;
  thumbnail: string;
  link: string;
  techStack: string[];
  category: string;
  status: 'completed' | 'ongoing' | 'maintenance';
}

const projects: Project[] = [
  {
    id: 1,
    name: 'Hiprotech Website',
    description: 'Modern corporate website built with cutting-edge web technologies. Features responsive design, interactive components, and optimized performance for seamless user experience.',
    thumbnail: '/uploads/projects/hiprotech-preview.jpg',
    link: 'https://hiprotech.org/',
    techStack: ['Nodejs', 'Next.js', 'TypeScript', 'Tailwind CSS'],
    category: 'Web Development',
    status: 'completed'
  },
  {
    id: 2,
    name: 'Young Entrepreneur Network',
    description: 'Dynamic platform connecting young entrepreneurs worldwide. Features networking tools, mentorship programs, and resource sharing for startup success.',
    thumbnail: '/uploads/projects/yen-preview.jpg',
    link: 'https://yenuniversal.org/',
    techStack: ['NextJs', 'Node.js', 'MongoDB', 'Express'],
    category: 'Social Platform',
    status: 'completed'
  },
  {
    id: 3,
    name: 'DAV School Project',
    description: 'Comprehensive educational management system for DAV schools. Includes student portals, academic tracking, and administrative tools for enhanced learning experience.',
    thumbnail: '/uploads/projects/dav-preview.jpg',
    link: 'http://www.davschool.org/',
    techStack: ['Spring Boot', 'NextJs', 'JavaScript', 'Bootstrap'],
    category: 'Education',
    status: 'completed'
  },
  {
    id: 4,
    name: 'Khanamart (Cloud Kitchen)',
    description: 'Complete cloud kitchen solution with online ordering, delivery management, and inventory tracking. Streamlines food business operations with modern technology.',
    thumbnail: '/uploads/projects/khanamart-preview.jpg',
    link: 'https://khanamart.in/',
    techStack: ['Next.js', 'Spring Boot',  'Hostinger'],
    category: 'E-Commerce',
    status: 'completed'
  }
];

const getStatusColor = (status: Project['status']) => {
  switch (status) {
    case 'completed':
      return 'bg-green-100 text-green-800';
    case 'ongoing':
      return 'bg-blue-100 text-blue-800';
    case 'maintenance':
      return 'bg-yellow-100 text-yellow-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export default function WorkPage() {
  return (
    <div className="bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-100 min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-purple-600 to-blue-600 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 z-0">
          {/* Subtle Gradient Orbs */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-blue-400/10 rounded-full blur-2xl"></div>
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-purple-400/8 rounded-full blur-xl"></div>
          
          {/* Portfolio Elements */}
          <div className="absolute top-16 right-20 w-12 h-12 bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg rotate-12 animate-float">
            <div className="flex items-center justify-center h-full">
              <EyeIcon className="w-6 h-6 text-blue-300" />
            </div>
          </div>

          <div className="absolute top-32 left-16 w-10 h-10 bg-white/10 backdrop-blur-sm border border-white/20 rounded-md -rotate-12 animate-float delay-500">
            <div className="flex items-center justify-center h-full">
              <RocketLaunchIcon className="w-5 h-5 text-purple-300" />
            </div>
          </div>

          <div className="absolute bottom-24 right-32 w-14 h-14 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl rotate-45 animate-float delay-700">
            <div className="flex items-center justify-center h-full">
              <CubeTransparentIcon className="w-7 h-7 text-blue-300" />
            </div>
          </div>

          {/* Simple Grid Pattern */}
          <div className="absolute inset-0 opacity-3">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255, 255, 255, 0.2) 1px, transparent 0)',
              backgroundSize: '40px 40px'
            }}></div>
          </div>
        </div>

        {/* Content */}
        <div className="container-custom py-8 md:py-10 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            {/* Portfolio Badge */}
            <div className="inline-flex items-center px-3 py-1 bg-white/15 border border-white/20 rounded-full text-white text-xs font-medium mb-4">
              <SparklesIcon className="w-3 h-3 mr-2" />
              Our Portfolio Showcase
            </div>
            
            {/* Main Heading */}
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white leading-tight mb-3">
              Our Creative
              <span className="block bg-gradient-to-r from-blue-200 to-purple-200 bg-clip-text text-transparent">
                Work Portfolio
              </span>
            </h1>
            
            {/* Description */}
            <p className="text-sm lg:text-base text-blue-100/90 mb-6 max-w-2xl mx-auto leading-relaxed">
              Discover our 
              <span className="font-semibold text-blue-200"> innovative projects </span>
              and digital solutions that have helped businesses transform their digital presence 
              and achieve remarkable success.
            </p>

            {/* Project Categories */}
            <div className="flex justify-center items-center gap-3 mb-6">
              <div className="flex items-center space-x-1 bg-white/10 px-3 py-1 rounded-md">
                <GlobeAltIcon className="w-4 h-4 text-blue-300" />
                <span className="text-white text-xs">Web</span>
              </div>
              
              <div className="flex items-center space-x-1 bg-white/10 px-3 py-1 rounded-md">
                <DevicePhoneMobileIcon className="w-4 h-4 text-purple-300" />
                <span className="text-white text-xs">Mobile</span>
              </div>
              
              <div className="flex items-center space-x-1 bg-white/10 px-3 py-1 rounded-md">
                <PaintBrushIcon className="w-4 h-4 text-blue-300" />
                <span className="text-white text-xs">Design</span>
              </div>
            </div>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
              <Link
                href="#projects"
                className="group inline-flex items-center justify-center px-5 py-2 text-sm font-semibold text-white bg-white/20 border border-white/30 rounded-md hover:bg-white/30 transform hover:scale-105 transition-all duration-300"
              >
                Explore Projects
                <ArrowRightIcon className="ml-2 w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                href="/contact"
                className="inline-flex items-center justify-center px-5 py-2 text-sm font-semibold text-purple-200 border border-purple-300/50 rounded-md hover:bg-white/10 transition-all duration-300"
              >
                Start Your Project
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Website Development Process Section - Snake Diagram */}
      <section className="py-4 md:py-5 relative overflow-hidden">
        {/* Subtle Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-50/50 to-blue-50/30"></div>
        
        <div className="container mx-auto px-2 sm:px-4 lg:px-6 relative z-10">
          {/* Compact Section Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-blue-500/10 border border-blue-200/50 text-blue-600 text-xs font-medium mb-3">
              <CubeTransparentIcon className="w-3 h-3 mr-1" />
              Development Process
            </div>
            
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">
              8 Steps of Website Development Process
            </h2>
            
            <p className="text-sm text-gray-600 max-w-xl mx-auto">
              Our proven methodology ensures quality delivery from concept to maintenance.
            </p>
          </div>

          {/* Snake Process Diagram */}
          <div className="relative max-w-5xl mx-auto">
            <svg 
              viewBox="0 0 1000 340" 
              className="w-full h-auto"
              preserveAspectRatio="xMidYMid meet"
            >
              {/* Enhanced Snake Path with Better Curves */}
              <defs>
                <linearGradient id="mainGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#3B82F6" />
                  <stop offset="25%" stopColor="#6366F1" />
                  <stop offset="50%" stopColor="#8B5CF6" />
                  <stop offset="75%" stopColor="#06B6D4" />
                  <stop offset="100%" stopColor="#3B82F6" />
                </linearGradient>
                
                <linearGradient id="innerGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#60A5FA" />
                  <stop offset="25%" stopColor="#818CF8" />
                  <stop offset="50%" stopColor="#A78BFA" />
                  <stop offset="75%" stopColor="#22D3EE" />
                  <stop offset="100%" stopColor="#60A5FA" />
                </linearGradient>
                
                {/* Enhanced glow effect */}
                <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
                  <feMerge> 
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
                
                {/* Subtle shadow */}
                <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="2" dy="4" stdDeviation="3" floodColor="#000000" floodOpacity="0.2"/>
                </filter>
              </defs>
              
              {/* Main Snake Path - More Natural Flow */}
              <path
                d="M 90 90 
                   C 200 50, 300 50, 400 90
                   C 500 130, 600 130, 700 90
                   C 800 50, 850 70, 880 110
                   C 910 150, 900 180, 870 200
                   C 840 220, 750 240, 650 200
                   C 550 160, 450 160, 350 200
                   C 250 240, 170 230, 120 200
                   C 70 170, 60 190, 90 230"
                stroke="url(#mainGradient)"
                strokeWidth="36"
                strokeLinecap="round"
                fill="none"
                filter="url(#shadow)"
                className="opacity-90"
              />
              
              {/* Inner highlight for depth */}
              <path
                d="M 90 90 
                   C 200 50, 300 50, 400 90
                   C 500 130, 600 130, 700 90
                   C 800 50, 850 70, 880 110
                   C 910 150, 900 180, 870 200
                   C 840 220, 750 240, 650 200
                   C 550 160, 450 160, 350 200
                   C 250 240, 170 230, 120 200
                   C 70 170, 60 190, 90 230"
                stroke="url(#innerGradient)"
                strokeWidth="20"
                strokeLinecap="round"
                fill="none"
                opacity="0.8"
              />
              
              {/* Subtle inner glow */}
              <path
                d="M 90 90 
                   C 200 50, 300 50, 400 90
                   C 500 130, 600 130, 700 90
                   C 800 50, 850 70, 880 110
                   C 910 150, 900 180, 870 200
                   C 840 220, 750 240, 650 200
                   C 550 160, 450 160, 350 200
                   C 250 240, 170 230, 120 200
                   C 70 170, 60 190, 90 230"
                stroke="rgba(255,255,255,0.4)"
                strokeWidth="8"
                strokeLinecap="round"
                fill="none"
                opacity="0.6"
              />
              
              {/* Step Circles with Enhanced Design */}
              {[
                { step: "01", title: "Requirements", x: 120, y: 75, color: "#3B82F6", bgColor: "#EBF8FF" },
                { step: "02", title: "Planning", x: 280, y: 75, color: "#6366F1", bgColor: "#EEF2FF" },
                { step: "03", title: "Design", x: 440, y: 75, color: "#8B5CF6", bgColor: "#FAF5FF" },
                { step: "04", title: "Content", x: 600, y: 75, color: "#06B6D4", bgColor: "#ECFEFF" },
                { step: "05", title: "Coding", x: 760, y: 75, color: "#3B82F6", bgColor: "#EBF8FF" },
                { step: "06", title: "Testing", x: 720, y: 185, color: "#8B5CF6", bgColor: "#FAF5FF" },
                { step: "07", title: "Launch", x: 480, y: 185, color: "#06B6D4", bgColor: "#ECFEFF" },
                { step: "08", title: "Support", x: 120, y: 215, color: "#6366F1", bgColor: "#EEF2FF" }
              ].map((item, index) => (
                <g key={index} className="cursor-pointer group">
                  {/* Outer glow effect */}
                  <circle
                    cx={item.x}
                    cy={item.y}
                    r="35"
                    fill={item.color}
                    opacity="0.08"
                    className="group-hover:opacity-15 transition-all duration-500"
                  />
                  
                  {/* Medium glow */}
                  <circle
                    cx={item.x}
                    cy={item.y}
                    r="28"
                    fill={item.color}
                    opacity="0.12"
                    className="group-hover:opacity-20 transition-all duration-400"
                  />
                  
                  {/* Main circle background */}
                  <circle
                    cx={item.x}
                    cy={item.y}
                    r="22"
                    fill="white"
                    stroke={item.color}
                    strokeWidth="3"
                    filter="url(#shadow)"
                    className="group-hover:r-24 group-hover:stroke-4 transition-all duration-300"
                  />
                  
                  {/* Inner colored background */}
                  <circle
                    cx={item.x}
                    cy={item.y}
                    r="19"
                    fill={item.bgColor}
                    opacity="0.3"
                    className="group-hover:opacity-50 transition-all duration-300"
                  />
                  
                  {/* Step Number */}
                  <text
                    x={item.x}
                    y={item.y + 4}
                    textAnchor="middle"
                    className="text-sm font-bold transition-all duration-300 group-hover:text-base"
                    style={{ fill: item.color }}
                  >
                    {item.step}
                  </text>
                  
                  {/* Step Title with better typography */}
                  <text
                    x={item.x}
                    y={item.y + 45}
                    textAnchor="middle"
                    className="text-xs font-semibold fill-gray-700 group-hover:fill-gray-900 transition-all duration-300"
                    style={{ fontSize: '12px' }}
                  >
                    {item.title}
                  </text>
                  
                  {/* Animated dot indicators */}
                  <circle
                    cx={item.x + 8}
                    cy={item.y - 8}
                    r="1.5"
                    fill={item.color}
                    opacity="0"
                    className="group-hover:opacity-60 transition-all duration-500"
                  >
                    <animate attributeName="opacity" values="0;0.8;0" dur="2s" repeatCount="indefinite"/>
                  </circle>
                </g>
              ))}
              
              {/* Decorative elements for visual enhancement */}
              <circle cx="50" cy="70" r="3" fill="#3B82F6" opacity="0.2">
                <animate attributeName="opacity" values="0.2;0.6;0.2" dur="3s" repeatCount="indefinite"/>
              </circle>
              <circle cx="920" cy="90" r="2.5" fill="#8B5CF6" opacity="0.3">
                <animate attributeName="opacity" values="0.3;0.7;0.3" dur="4s" repeatCount="indefinite"/>
              </circle>
              <circle cx="80" cy="260" r="2" fill="#06B6D4" opacity="0.25">
                <animate attributeName="opacity" values="0.25;0.5;0.25" dur="5s" repeatCount="indefinite"/>
              </circle>
            </svg>
          </div>

          {/* Process Details Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 max-w-6xl mx-auto mt-6">
            {[
              {
                step: "01",
                title: "Requirements",
                description: "Understanding your needs",
                icon: ClipboardDocumentListIcon,
                bgColor: "bg-blue-50",
                borderColor: "border-blue-200",
                textColor: "text-blue-600",
                circleColor: "bg-blue-500"
              },
              {
                step: "02",
                title: "Planning", 
                description: "Creating project roadmap",
                icon: ChartBarIcon,
                bgColor: "bg-purple-50",
                borderColor: "border-purple-200", 
                textColor: "text-purple-600",
                circleColor: "bg-purple-500"
              },
              {
                step: "03",
                title: "Design",
                description: "Crafting user experience",
                icon: PaintBrushIcon,
                bgColor: "bg-cyan-50",
                borderColor: "border-cyan-200",
                textColor: "text-cyan-600", 
                circleColor: "bg-cyan-500"
              },
              {
                step: "04",
                title: "Content",
                description: "Writing compelling copy",
                icon: DocumentTextIcon,
                bgColor: "bg-blue-50",
                borderColor: "border-blue-200",
                textColor: "text-blue-600",
                circleColor: "bg-blue-500"
              },
              {
                step: "05",
                title: "Coding",
                description: "Building with clean code",
                icon: CodeBracketIcon,
                bgColor: "bg-violet-50",
                borderColor: "border-violet-200",
                textColor: "text-violet-600",
                circleColor: "bg-violet-500"
              },
              {
                step: "06",
                title: "Testing",
                description: "Quality assurance",
                icon: MagnifyingGlassIcon,
                bgColor: "bg-cyan-50",
                borderColor: "border-cyan-200",
                textColor: "text-cyan-600",
                circleColor: "bg-cyan-500"
              },
              {
                step: "07",
                title: "Launch",
                description: "Going live successfully", 
                icon: RocketLaunchIcon,
                bgColor: "bg-indigo-50",
                borderColor: "border-indigo-200",
                textColor: "text-indigo-600",
                circleColor: "bg-indigo-500"
              },
              {
                step: "08",
                title: "Support",
                description: "Ongoing maintenance",
                icon: WrenchScrewdriverIcon,
                bgColor: "bg-blue-50",
                borderColor: "border-blue-200",
                textColor: "text-blue-600",
                circleColor: "bg-blue-500"
              }
            ].map((item, index) => (
              <div key={index} className="group">
                <div className={`p-2.5 rounded-lg ${item.bgColor} backdrop-blur-sm border ${item.borderColor} hover:shadow-md transition-all duration-300`}>
                  <div className="flex items-center mb-2">
                    <div className={`w-6 h-6 rounded-full ${item.circleColor} text-white text-xs font-bold flex items-center justify-center mr-2`}>
                      {item.step}
                    </div>
                    <item.icon className={`w-4 h-4 ${item.textColor}`} />
                  </div>
                  
                  <h3 className="text-sm font-semibold text-gray-900 mb-1">
                    {item.title}
                  </h3>
                  
                  <p className="text-xs text-gray-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Compact Call to Action */}
          {/* <div className="text-center mt-6">
            <div className="bg-gradient-to-r from-blue-500/5 to-purple-500/5 rounded-xl p-4 backdrop-blur-sm border border-blue-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Ready to Start Your Project?
              </h3>
              <p className="text-sm text-gray-600 mb-3 max-w-md mx-auto">
                Let&apos;s transform your ideas into a successful digital solution.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link
                  href="/contact"
                  className="inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg hover:from-blue-700 hover:to-purple-700 transform hover:scale-105 transition-all duration-300 shadow-lg"
                >
                  Get Started
                  <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </Link>
                <Link
                  href="/services"
                  className="inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-blue-600 bg-white/70 border border-blue-200 rounded-lg hover:bg-blue-50 transition-all duration-300"
                >
                  View Services
                </Link>
              </div>
            </div>
          </div> */}
        </div>
      </section>

      {/* Projects Grid Section */}
      <section id="projects" className="py-4 md:py-6 bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-2 sm:px-4 lg:px-6">
          <div className="text-center mb-4">
            <h2 className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-900 mb-1">
              Featured <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Projects</span>
            </h2>
            <p className="text-xs text-gray-600 max-w-lg mx-auto">
              A showcase of our latest work across various industries and technologies.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 max-w-5xl mx-auto">
            {projects.map((project) => (
              <div key={project.id} className="group relative">
                <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-100 group-hover:-translate-y-1 group-hover:scale-102">
                  {/* Project Thumbnail */}
                  <div className="relative overflow-hidden bg-gradient-to-br from-cyan-100 to-blue-100 h-28">
                    {/* Placeholder for project image */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center shadow-md">
                        <GlobeAltIcon className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    
                    {/* Status Badge */}
                    <div className="absolute top-1.5 left-1.5">
                      <span className={`px-1.5 py-0.5 text-xs font-medium rounded ${getStatusColor(project.status)} capitalize`}>
                        {project.status}
                      </span>
                    </div>
                    
                    {/* Category Badge */}
                    <div className="absolute top-1.5 right-1.5">
                      <span className="px-1.5 py-0.5 bg-white/90 backdrop-blur-sm text-gray-700 text-xs font-medium rounded">
                        {project.category}
                      </span>
                    </div>
                    
                    {/* Overlay on hover */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="absolute bottom-1.5 left-1.5 right-1.5">
                        <div className="flex items-center justify-center">
                          <EyeIcon className="w-4 h-4 text-white" />
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Project Details */}
                  <div className="p-3">
                    <h3 className="text-sm font-bold text-gray-900 mb-1 group-hover:text-cyan-600 transition-colors line-clamp-1">
                      {project.name}
                    </h3>
                    
                    <p className="text-gray-600 text-xs leading-relaxed mb-2 line-clamp-2">
                      {project.description}
                    </p>
                    
                    {/* Tech Stack */}
                    <div className="mb-2">
                      <div className="flex flex-wrap gap-1">
                        {project.techStack.slice(0, 2).map((tech) => {
                          return (
                            <span 
                              key={tech}
                              className="inline-flex items-center px-1.5 py-0.5 bg-gradient-to-r from-cyan-50 to-blue-50 text-cyan-700 text-xs rounded border border-cyan-200"
                            >
                              {tech}
                            </span>
                          );
                        })}
                        {project.techStack.length > 2 && (
                          <span className="text-xs text-gray-500">+{project.techStack.length - 2}</span>
                        )}
                      </div>
                    </div>
                    
                    {/* CTA Button */}
                    <div className="flex gap-1">
                      {project.link !== '#' ? (
                        <a
                          href={project.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex-1 group/btn inline-flex items-center justify-center px-2 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded hover:from-cyan-600 hover:to-blue-700 transition-all duration-300 shadow-sm hover:shadow-md"
                        >
                          View
                          <ArrowTopRightOnSquareIcon className="ml-1 w-3 h-3 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                        </a>
                      ) : (
                        <button 
                          disabled
                          className="flex-1 inline-flex items-center justify-center px-2 py-1.5 text-xs font-semibold text-gray-400 bg-gray-100 rounded cursor-not-allowed"
                        >
                          Soon
                        </button>
                      )}
                      
                      <button className="inline-flex items-center justify-center px-2 py-1.5 text-xs font-semibold text-cyan-600 border border-cyan-400 rounded hover:bg-cyan-50 hover:border-cyan-500 transition-all duration-300">
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Load More Section */}
          <div className="text-center mt-4">
            <p className="text-gray-600 mb-2 text-xs">
              Want to see more of our work or discuss your project?
            </p>
            <div className="flex flex-col sm:flex-row gap-2 justify-center">
              <Link
                href="/contact"
                className="group inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg hover:from-cyan-600 hover:to-blue-700 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Discuss Your Project
                <svg className="ml-2 w-3 h-3 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </Link>
              <Link
                href="/about"
                className="inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-cyan-600 border border-cyan-400 rounded-lg hover:bg-cyan-50 hover:border-cyan-500 transition-all duration-300"
              >
                Learn About Us
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-3 md:py-4 bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-700 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0">
          <div className="absolute top-4 right-4 w-8 h-8 bg-white/10 rounded-full animate-pulse"></div>
          <div className="absolute bottom-4 left-4 w-6 h-6 bg-white/10 rounded-xl rotate-45" style={{animation: 'bounce 2.5s ease-in-out infinite'}}></div>
          
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255, 255, 255, 0.3) 1px, transparent 0)',
              backgroundSize: '30px 30px'
            }}></div>
          </div>
        </div>
        
        {/* <div className="container mx-auto px-2 sm:px-4 lg:px-6 relative z-10">
          <div className="text-center mb-2">
            <h2 className="text-lg sm:text-xl font-bold text-white mb-1">
              Our Impact in Numbers
            </h2>
            <p className="text-blue-100 text-xs max-w-md mx-auto">
              Every project represents a success story and a satisfied client.
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 max-w-2xl mx-auto">
            {[
              { number: '4+', label: 'Projects Live', icon: CodeBracketIcon },
              { number: '4+', label: 'Happy Clients', icon: EyeIcon },
              { number: '3+', label: 'Years Experience', icon: GlobeAltIcon },
              { number: '100%', label: 'Project Success', icon: DevicePhoneMobileIcon }
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg mb-2">
                  <stat.icon className="w-4 h-4 text-white" />
                </div>
                <div className="text-lg lg:text-xl font-bold text-white mb-1">{stat.number}</div>
                <div className="text-blue-100 font-medium text-xs">{stat.label}</div>
              </div>
            ))}
          </div>
        </div> */}
      </section>

      {/* CTA Section */}
      {/* <section className="py-4 bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-2 sm:px-4 lg:px-6 text-center">
          <div className="max-w-lg mx-auto">
            <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">
              Ready to Create Something
              <span className="block bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
                Amazing Together?
              </span>
            </h2>
            <p className="text-xs text-gray-600 mb-3 leading-relaxed">
              Let&apos;s discuss your project and bring your vision to life with our expertise.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-2 justify-center items-center">
              <Link
                href="/contact"
                className="group inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg hover:from-cyan-600 hover:to-blue-700 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Start Your Project
                <svg className="ml-2 w-3 h-3 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </Link>
              <Link
                href="/solutions"
                className="inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-cyan-600 border border-cyan-400 rounded-lg hover:bg-cyan-50 hover:border-cyan-500 transition-all duration-300"
              >
                View Our Services
              </Link>
            </div>
          </div>
        </div>
      </section> */}
    </div>
  );
}