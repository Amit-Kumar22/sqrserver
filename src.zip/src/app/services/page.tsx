'use client';

import { useState } from 'react';
import {
  CodeBracketIcon,
  DevicePhoneMobileIcon,
  ComputerDesktopIcon,
  ChartBarIcon,
  ShoppingCartIcon,
  PaintBrushIcon,
  ShareIcon,
  CheckIcon,
  ArrowRightIcon,
  SparklesIcon,
} from '@heroicons/react/24/outline';
import {
  CodeBracketIcon as CodeBracketIconSolid,
  DevicePhoneMobileIcon as DevicePhoneMobileIconSolid,
  ComputerDesktopIcon as ComputerDesktopIconSolid,
  ChartBarIcon as ChartBarIconSolid,
  ShoppingCartIcon as ShoppingCartIconSolid,
  PaintBrushIcon as PaintBrushIconSolid,
  ShareIcon as ShareIconSolid
} from '@heroicons/react/24/solid';

const services = [
  {
    name: 'Web Development',
    shortDescription: 'Modern, responsive websites that drive results',
    icon: CodeBracketIcon,
    iconSolid: CodeBracketIconSolid,
    gradient: 'from-blue-500 to-cyan-600',
    hoverColor: 'hover:border-blue-500',
    features: [
      'Responsive Websites – Modern, mobile-friendly designs that adapt seamlessly to any device',
      'E-commerce Platforms – Powerful online stores with secure payment integration',
      'Business Websites – Professional web presence that drives growth',
      'Custom Web Applications – Tailored solutions for unique business needs'
    ]
  },
  {
    name: 'App Development',
    shortDescription: 'Native and cross-platform mobile solutions',
    icon: DevicePhoneMobileIcon,
    iconSolid: DevicePhoneMobileIconSolid,
    gradient: 'from-green-500 to-emerald-600',
    hoverColor: 'hover:border-green-500',
    features: [
      'Android Apps – Native applications optimized for the Android ecosystem',
      'iOS Apps – Sleek, high-performance apps for Apple devices',
      'Cross-platform Solutions – Build once, deploy everywhere with React Native & Flutter',
      'UI/UX Focused Design – Intuitive interfaces that users love'
    ]
  },
  {
    name: 'iOS Apps',
    shortDescription: 'Premium Apple ecosystem applications',
    icon: ComputerDesktopIcon,
    iconSolid: ComputerDesktopIconSolid,
    gradient: 'from-purple-500 to-indigo-600',
    hoverColor: 'hover:border-purple-500',
    features: []
  },
  {
    name: 'SEO & Ads',
    shortDescription: 'Digital marketing and search optimization',
    icon: ChartBarIcon,
    iconSolid: ChartBarIconSolid,
    gradient: 'from-orange-500 to-red-600',
    hoverColor: 'hover:border-orange-500',
    features: []
  },
  {
    name: 'E-commerce',
    shortDescription: 'Complete online store solutions',
    icon: ShoppingCartIcon,
    iconSolid: ShoppingCartIconSolid,
    gradient: 'from-pink-500 to-rose-600',
    hoverColor: 'hover:border-pink-500',
    features: []
  },
  {
    name: 'Android Apps',
    shortDescription: 'Native Android development',
    icon: DevicePhoneMobileIcon,
    iconSolid: DevicePhoneMobileIconSolid,
    gradient: 'from-green-600 to-teal-600',
    hoverColor: 'hover:border-green-600',
    features: []
  },
  {
    name: 'UI/UX Design',
    shortDescription: 'Beautiful and functional user experiences',
    icon: PaintBrushIcon,
    iconSolid: PaintBrushIconSolid,
    gradient: 'from-violet-500 to-purple-600',
    hoverColor: 'hover:border-violet-500',
    features: []
  },
  {
    name: 'Social Media',
    shortDescription: 'Social media management and marketing',
    icon: ShareIcon,
    iconSolid: ShareIconSolid,
    gradient: 'from-blue-600 to-indigo-600',
    hoverColor: 'hover:border-blue-600',
    features: []
  }
];



export default function ServicesPage() {
  const [hoveredService, setHoveredService] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-cyan-50/50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 overflow-hidden min-h-[320px] shadow-2xl">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 z-0">
          {/* Large gradient orbs */}
          <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl -translate-x-48 -translate-y-48 animate-pulse"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl translate-x-48 translate-y-48 animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-indigo-500/15 rounded-full blur-2xl -translate-x-32 -translate-y-32 animate-bounce-slow"></div>

          {/* Floating Tech Icons */}
          <div className="absolute top-16 right-20 w-12 h-12 bg-gradient-to-br from-cyan-400/30 to-blue-500/30 rounded-xl rotate-12 flex items-center justify-center animate-float">
            <CodeBracketIcon className="w-6 h-6 text-cyan-300" />
          </div>
          
          <div className="absolute top-32 left-16 w-10 h-10 bg-gradient-to-br from-purple-400/25 to-indigo-500/25 rounded-lg -rotate-12 flex items-center justify-center animate-float delay-500">
            <DevicePhoneMobileIcon className="w-5 h-5 text-purple-300" />
          </div>

          <div className="absolute bottom-32 right-32 w-14 h-14 bg-gradient-to-br from-blue-400/20 to-cyan-500/20 rounded-full rotate-45 flex items-center justify-center animate-float delay-1000">
            <ComputerDesktopIcon className="w-7 h-7 text-blue-300" />
          </div>

          <div className="absolute bottom-20 left-20 w-8 h-8 bg-gradient-to-br from-green-400/30 to-emerald-500/30 rounded-md rotate-6 flex items-center justify-center animate-float delay-700">
            <ChartBarIcon className="w-4 h-4 text-green-300" />
          </div>

          {/* Connection Lines */}
          <div className="absolute top-1/4 right-1/3 w-32 h-px bg-gradient-to-r from-transparent via-cyan-400/40 to-transparent rotate-45 animate-pulse"></div>
          <div className="absolute bottom-1/3 left-1/4 w-24 h-px bg-gradient-to-r from-transparent via-blue-400/30 to-transparent -rotate-12 animate-pulse delay-500"></div>

          {/* Grid Pattern Overlay */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(99, 179, 237, 0.4) 1px, transparent 0)',
              backgroundSize: '40px 40px'
            }}></div>
          </div>

          {/* Particles */}
          <div className="absolute top-1/5 right-1/4 w-2 h-2 bg-cyan-400 rounded-full animate-ping opacity-60"></div>
          <div className="absolute bottom-1/4 right-1/5 w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse opacity-50 delay-300"></div>
          <div className="absolute top-3/5 left-1/6 w-1 h-1 bg-purple-400 rounded-full animate-bounce opacity-40"></div>
        </div>

        {/* Content Container */}
        <div className="container-custom py-12 md:py-16 relative z-10">
          <div className="text-center max-w-5xl mx-auto">
            {/* Badge with enhanced design */}
            <div className="inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r from-blue-500/10 to-cyan-500/10 backdrop-blur-sm border border-blue-400/30 text-blue-300 text-sm font-medium mb-6 shadow-lg">
              <SparklesIcon className="w-5 h-5 mr-3 animate-spin-slow" />
              <span className="bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent font-semibold">
                Comprehensive Digital Solutions
              </span>
            </div>

            {/* Enhanced Main Heading */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-tight mb-6">
              Our 
              <span className="block bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent animate-gradient">
                Services
              </span>
            </h1>

            {/* Enhanced Description */}
            <p className="text-lg lg:text-xl text-blue-100/90 leading-relaxed max-w-4xl mx-auto mb-8">
              From web development to mobile apps, we provide 
              <span className="font-semibold text-cyan-300"> end-to-end digital solutions </span>
              that transform your business and drive sustainable growth.
            </p>

            {/* Call-to-Action Stats */}
            <div className="flex flex-wrap justify-center gap-8 mt-8">
              <div className="flex items-center space-x-2 text-cyan-400 bg-white/5 px-4 py-2 rounded-lg backdrop-blur-sm">
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
                <span className="font-semibold">8+ Services</span>
              </div>
              <div className="flex items-center space-x-2 text-blue-400 bg-white/5 px-4 py-2 rounded-lg backdrop-blur-sm">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse delay-200"></div>
                <span className="font-semibold">Expert Team</span>
              </div>
              <div className="flex items-center space-x-2 text-purple-400 bg-white/5 px-4 py-2 rounded-lg backdrop-blur-sm">
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse delay-500"></div>
                <span className="font-semibold">24/7 Support</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Gradient Fade */}
        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white to-transparent z-15"></div>
      </section>

      {/* Services Grid */}
      <section className="relative bg-white py-8 md:py-12">
        <div className="container-custom">
          <div className="text-center mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3">
              Complete <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Digital Solutions</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-sm">
              Choose from our comprehensive range of services designed to elevate your digital presence
            </p>
          </div>

          <div className="grid gap-4 sm:gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((service, index) => {
              const IconComponent = hoveredService === index ? service.iconSolid : service.icon;
              
              return (
                <div
                  key={service.name}
                  className={`group relative bg-white p-4 rounded-xl border-2 border-gray-100 ${service.hoverColor} transition-all duration-300 hover:shadow-lg hover:-translate-y-1 cursor-pointer`}
                  onMouseEnter={() => setHoveredService(index)}
                  onMouseLeave={() => setHoveredService(null)}
                >
                  {/* Service Icon */}
                  <div className={`w-12 h-12 bg-gradient-to-br ${service.gradient} rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>

                  {/* Service Content */}
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-gray-700 transition-colors">
                      {service.name}
                    </h3>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {service.shortDescription}
                    </p>
                  </div>

                  {/* Hover Arrow */}
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <ArrowRightIcon className="w-5 h-5 text-gray-400" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Detailed Services Section */}
      <section className="relative bg-gradient-to-r from-gray-50 to-blue-50 py-8 md:py-12">
        <div className="container-custom">
          <div className="grid gap-8 lg:gap-12 lg:grid-cols-2 items-start">
            
            {/* Web Development Details */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-lg flex items-center justify-center mr-3">
                  <CodeBracketIconSolid className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">
                  Web Development
                </h3>
              </div>

              <div className="space-y-3">
                {services[0].features.map((feature, index) => (
                  <div key={index} className="flex items-start">
                    <div className="flex-shrink-0 w-2 h-2 bg-cyan-500 rounded-full mt-2 mr-3"></div>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      <span className="font-medium text-gray-900">
                        {feature.split(' – ')[0]}
                      </span>
                      {feature.includes(' – ') && (
                        <span> – {feature.split(' – ')[1]}</span>
                      )}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* App Development Details */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center mr-3">
                  <DevicePhoneMobileIconSolid className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">
                  App Development
                </h3>
              </div>

              <div className="space-y-3">
                {services[1].features.map((feature, index) => (
                  <div key={index} className="flex items-start">
                    <div className="flex-shrink-0 w-2 h-2 bg-green-500 rounded-full mt-2 mr-3"></div>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      <span className="font-medium text-gray-900">
                        {feature.split(' – ')[0]}
                      </span>
                      {feature.includes(' – ') && (
                        <span> – {feature.split(' – ')[1]}</span>
                      )}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Approach Section */}
      <section className="relative bg-white py-8 md:py-12">
        <div className="container-custom">
          <div className="grid gap-8 lg:gap-12 lg:grid-cols-2 items-center">
            
            {/* Approach Content */}
            <div>
              <div className="inline-flex items-center px-3 py-1.5 rounded-full bg-cyan-100 text-cyan-800 text-sm font-medium mb-4">
                <CheckIcon className="w-4 h-4 mr-2" />
                Our Methodology
              </div>
              
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
                Our <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Approach</span>
              </h2>
              
              <p className="text-gray-600 leading-relaxed mb-6">
                We combine cutting-edge technology with creative design to deliver 
                digital products that drive results. Every project is built with 
                scalability, performance, and user experience at its core. From 
                concept to deployment, we ensure your vision becomes reality.
              </p>

              <div className="space-y-3">
                <div className="flex items-center">
                  <CheckIcon className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-sm text-gray-700">Strategic planning and analysis</span>
                </div>
                <div className="flex items-center">
                  <CheckIcon className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-sm text-gray-700">Agile development methodology</span>
                </div>
                <div className="flex items-center">
                  <CheckIcon className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-sm text-gray-700">Quality assurance and testing</span>
                </div>
                <div className="flex items-center">
                  <CheckIcon className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-sm text-gray-700">Ongoing support and maintenance</span>
                </div>
              </div>
            </div>

            {/* Team Image Placeholder */}
            <div className="relative">
              <div className="relative bg-gradient-to-br from-cyan-100 to-blue-100 rounded-2xl p-8 border border-cyan-200">
                {/* Floating elements */}
                <div className="absolute top-4 right-4 w-8 h-8 bg-cyan-500 rounded-lg opacity-20"></div>
                <div className="absolute bottom-4 left-4 w-6 h-6 bg-blue-500 rounded-full opacity-30"></div>
                <div className="absolute top-1/2 left-8 w-4 h-4 bg-indigo-500 rounded-full opacity-25"></div>
                
                {/* Team meeting representation */}
                <div className="bg-white rounded-xl p-6 shadow-lg">
                  <div className="flex items-center justify-center space-x-2 mb-4">
                    <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-bold">T</span>
                    </div>
                    <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-bold">E</span>
                    </div>
                    <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-bold">A</span>
                    </div>
                    <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-bold">M</span>
                    </div>
                  </div>
                  <div className="text-center">
                    <h4 className="font-semibold text-gray-900 mb-2">Collaborative Process</h4>
                    <p className="text-xs text-gray-600">
                      Working together to bring your ideas to life through innovative technology solutions
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Simple Clean Process Section */}
      <section className="relative bg-gray-50 py-12 md:py-16">
        <div className="container-custom max-w-5xl">
          <div className="text-center mb-10">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3">
              Our Work Process
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We follow a simple and effective process to deliver the best results
            </p>
          </div>

          {/* Simple Process Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                number: "01",
                title: "Planning",
                description: "We understand your requirements and create a detailed plan",
                color: "bg-blue-500"
              },
              {
                number: "02",
                title: "Design",
                description: "Our designers create beautiful and user-friendly interfaces",
                color: "bg-green-500"
              },
              {
                number: "03",
                title: "Development",
                description: "We build your project using latest technologies",
                color: "bg-purple-500"
              },
              {
                number: "04",
                title: "Testing",
                description: "We thoroughly test everything to ensure quality",
                color: "bg-orange-500"
              },
              {
                number: "05",
                title: "Launch",
                description: "We deploy your project and make it live",
                color: "bg-red-500"
              },
              {
                number: "06",
                title: "Support",
                description: "We provide ongoing support and maintenance",
                color: "bg-cyan-500"
              }
            ].map((step) => (
              <div key={step.number} className="group">
                <div className="bg-white p-6 rounded-lg border border-gray-200 hover:border-gray-300 hover:shadow-md transition-all duration-200">
                  {/* Step Number */}
                  <div className="flex items-center mb-4">
                    <div className={`${step.color} text-white font-bold text-sm px-3 py-1 rounded-full mr-3`}>
                      {step.number}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {step.title}
                    </h3>
                  </div>
                  
                  {/* Description */}
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Simple Call to Action */}
          <div className="text-center mt-12">
            <div className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-lg text-sm">
              <CheckIcon className="w-4 h-4 mr-2" />
              Ready to start your project? Let&apos;s work together!
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative bg-gradient-to-r from-cyan-600 to-blue-600 py-8">
        <div className="container-custom text-center">
          <h2 className="text-xl sm:text-2xl font-bold text-white mb-3">
            Ready to Transform Your Business?
          </h2>
          <p className="text-cyan-100 mb-6 max-w-2xl mx-auto text-sm">
            Let&apos;s discuss your project and create something amazing together. 
            Get in touch with our team today.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
            <a
              href="/contact"
              className="inline-flex items-center px-6 py-3 text-sm font-semibold text-cyan-600 bg-white rounded-lg hover:bg-gray-50 transform hover:scale-105 transition-all duration-300 shadow-lg"
            >
              Start Your Project
              <ArrowRightIcon className="ml-2 h-4 w-4" />
            </a>
            <a
              href="/work"
              className="inline-flex items-center px-6 py-3 text-sm font-semibold text-white border-2 border-white/30 rounded-lg hover:bg-white/10 transition-all duration-300"
            >
              View Our Work
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}