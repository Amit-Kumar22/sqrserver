import Link from 'next/link';
import { ArrowRightIcon, CodeBracketIcon, BeakerIcon, CpuChipIcon, ShieldCheckIcon, RocketLaunchIcon, ChartBarIcon } from '@heroicons/react/24/outline';

const features = [
  {
    name: 'Custom Software Development',
    description: 'Tailored software solutions built with cutting-edge technologies to meet your specific business requirements.',
    icon: CodeBracketIcon,
  },
  {
    name: 'Research & Development',
    description: 'Innovation-driven R&D services focusing on emerging technologies, AI/ML, and next-generation solutions.',
    icon: BeakerIcon,
  },
  {
    name: 'System Architecture',
    description: 'Scalable and robust system architecture design for enterprise-grade applications and platforms.',
    icon: CpuChipIcon,
  },
  {
    name: 'Security Solutions',
    description: 'Comprehensive cybersecurity solutions to protect your digital assets and ensure data integrity.',
    icon: ShieldCheckIcon,
  },
];

const stats = [
  { name: 'Projects Completed', value: '18+', icon: RocketLaunchIcon },
  { name: 'Years Experience', value: '3+', icon: ChartBarIcon },
  { name: 'Technologies Mastered', value: '25+', icon: CodeBracketIcon },
  { name: 'Client Satisfaction', value: '90%', icon: ShieldCheckIcon },
];

const team = [
  {
    name: 'Abhishek Kumar',
    role: 'CEO & Founder',
    expertise: 'AI, Cloud Computing, IT Strategy',
    experience: '10+ years',
  },
  {
    name: 'Salony Pandey',
    role: 'Project Manager',
    expertise: 'Agile, DevOps, Client Relations',
    experience: '4+ years',
    
  },
  {
    name: ' Amit Kumar',
    role: 'Full Stack Developer',
    expertise: 'Backend, Frontend, DevOps',
    experience: '3+ years',
  },
  {
    name: 'Aachal Priya',
    role: 'Web Developer',
    expertise: 'Frontend, UI/UX Design Mobile Apps',
    experience: ' 2 years',
  },
];

export default function HomePage() {
  return (
    <div className="relative overflow-hidden">
      {/* Hero Section - Space Theme */}
      <section className="relative h-[45vh] min-h-[450px] max-h-[550px] bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          {/* Large Planet/Sphere */}
          <div className="absolute top-0 right-0 w-96 h-96 lg:w-[500px] lg:h-[500px] -translate-y-20 translate-x-20">
            <div className="w-full h-full rounded-full bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600 opacity-80 animate-pulse shadow-2xl">
              <div className="absolute inset-4 rounded-full bg-gradient-to-br from-blue-300/30 to-transparent"></div>
              <div className="absolute inset-8 rounded-full bg-gradient-to-br from-white/20 to-transparent"></div>
            </div>
          </div>

          {/* Floating Geometric Shapes */}
          <div className="absolute top-1/4 left-1/4 w-16 h-16 animate-bounce-slow">
            <div className="w-full h-full bg-gradient-to-br from-cyan-400 to-blue-500 transform rotate-45 rounded-lg opacity-70 shadow-lg"></div>
          </div>
          
          <div className="absolute top-1/3 right-1/3 w-12 h-12 animate-float">
            <div className="w-full h-full bg-gradient-to-br from-purple-400 to-pink-500 rounded-full opacity-60 shadow-lg"></div>
          </div>

          <div className="absolute bottom-1/4 left-1/5 w-20 h-20 animate-pulse">
            <div className="w-full h-full bg-gradient-to-br from-indigo-400 to-purple-500 transform rotate-12 rounded-xl opacity-50 shadow-lg"></div>
          </div>

          {/* Starfield Effect */}
          <div className="absolute inset-0">
            {[...Array(50)].map((_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 bg-white rounded-full opacity-70 animate-twinkle"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 3}s`,
                  animationDuration: `${2 + Math.random() * 2}s`
                }}
              />
            ))}
          </div>

          {/* Grid Pattern Overlay */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(99, 179, 237, 0.3) 1px, transparent 0)',
              backgroundSize: '60px 60px'
            }}></div>
          </div>
        </div>

        {/* Main Content */}
        <div className="relative z-10 container-custom h-full flex items-center py-8">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center w-full">
            {/* Left Content */}
            <div className="space-y-6 lg:space-y-8">
              <div className="space-y-3">
                <div className="inline-flex items-center px-3 py-1.5 rounded-full bg-blue-500/10 backdrop-blur-sm border border-blue-400/30 text-blue-300 text-sm font-medium">
                  <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse mr-2"></span>
                  NEXYRA DIGITAL
                </div>
                
                <h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold text-white leading-tight">
                  The largest tech
                  <span className="block bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                    show where we
                  </span>
                  <span className="block text-white">
                    present our brand
                  </span>
                </h1>
              </div>
              
              <p className="text-base lg:text-lg text-blue-100/80 leading-relaxed max-w-xl">
                Join us in the most innovative technology showcase where cutting-edge 
                solutions meet extraordinary digital experiences. Discover the future of tech with NexyraTech.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <Link 
                  href="/contact" 
                  className="group inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-white bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full hover:from-blue-600 hover:to-cyan-600 transform hover:scale-105 transition-all duration-300 shadow-xl hover:shadow-2xl"
                >
                  Get Started Today
                  <ArrowRightIcon className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link 
                  href="/projects" 
                  className="inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-blue-300 border-2 border-blue-400/50 rounded-full hover:bg-blue-500/10 hover:border-blue-400 transition-all duration-300 backdrop-blur-sm"
                >
                  Explore Projects  
                </Link>
              </div>
            </div>

            {/* Right Content - 3D Element */}
            <div className="relative flex items-center justify-center lg:justify-end">
              <div className="relative w-64 h-64 lg:w-80 lg:h-80">
                {/* Main 3D Cube */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative w-24 h-24 lg:w-32 lg:h-32 animate-float">
                    {/* Cube faces */}
                    <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/80 to-blue-600/80 transform preserve-3d">
                      <div className="absolute inset-0 bg-gradient-to-br from-cyan-300/90 to-blue-500/90 transform rotateY-45 rotateX-15 skew-y-12 rounded-lg shadow-2xl"></div>
                      <div className="absolute inset-0 bg-gradient-to-br from-blue-400/70 to-indigo-600/70 transform -rotateY-45 rotateX-15 skew-y-12 rounded-lg shadow-2xl translate-x-4"></div>
                      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/60 to-blue-700/60 transform rotateX-45 skew-x-12 rounded-lg shadow-2xl -translate-y-4"></div>
                    </div>
                  </div>
                </div>

                {/* Orbiting Elements */}
                <div className="absolute inset-0">
                  {[0, 120, 240].map((rotation, i) => (
                    <div
                      key={i}
                      className="absolute w-6 h-6 bg-gradient-to-br from-cyan-300 to-blue-400 rounded-full shadow-lg animate-orbit"
                      style={{
                        top: '50%',
                        left: '50%',
                        transform: `translate(-50%, -50%) rotate(${rotation}deg) translateX(100px) rotate(-${rotation}deg)`,
                        animationDelay: `${i * 0.8}s`
                      }}
                    />
                  ))}
                </div>

                {/* Connecting Lines */}
                <div className="absolute inset-0">
                  <svg className="w-full h-full animate-pulse" viewBox="0 0 200 200">
                    <circle cx="100" cy="100" r="80" fill="none" stroke="rgba(99, 179, 237, 0.3)" strokeWidth="1" strokeDasharray="4,4"/>
                    <circle cx="100" cy="100" r="60" fill="none" stroke="rgba(99, 179, 237, 0.2)" strokeWidth="1"/>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative bg-white">
        <div className="container-custom py-12 md:py-16">
          <div className="grid grid-cols-2 gap-6 sm:grid-cols-4">
            {stats.map((stat) => (
              <div key={stat.name} className="text-center group">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-3 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 group-hover:scale-110 transition-transform duration-300">
                  <stat.icon className="h-5 w-5 text-white" />
                </div>
                <p className="text-2xl font-bold text-gray-800 mb-2 group-hover:text-cyan-600 transition-colors">
                  {stat.value}
                </p>
                <p className="text-sm text-gray-600">{stat.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative bg-white">
        <div className="container-custom py-16 md:py-20 relative">
          <div className="mx-auto max-w-3xl text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-4">
              Comprehensive
              <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent"> Technology Solutions</span>
            </h2>
            <p className="text-base lg:text-lg text-gray-600">
              We deliver end-to-end technology solutions tailored to accelerate your business growth.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {features.map((feature) => (
              <div key={feature.name} className="group relative">
                <div className="relative p-8 rounded-xl bg-white shadow-lg hover:shadow-xl transition-all duration-300 border-l-4 border-cyan-400">
                  <div className="flex items-center mb-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 group-hover:scale-110 transition-transform duration-300">
                      <feature.icon className="h-5 w-5 text-white" />
                    </div>
                    <h3 className="ml-3 text-lg font-semibold text-gray-800 group-hover:text-cyan-600 transition-colors">
                      {feature.name}
                    </h3>
                  </div>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="relative bg-gradient-to-r from-slate-50 to-blue-50">
        <div className="container-custom py-12 md:py-16">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3">
              Our Expert <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Team</span>
            </h2>
            <p className="text-base text-gray-600 max-w-3xl mx-auto">
              Meet the passionate professionals driving innovation and delivering exceptional results for our clients.
            </p>
          </div>
          
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {team.map((member) => (
              <div key={member.name} className="group relative">
                <div className="bg-white p-4 rounded-lg shadow-lg hover:shadow-xl border border-gray-100 transition-all duration-300 text-center h-48 flex flex-col">
                  {/* Avatar */}
                  <div className="relative mb-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg mx-auto flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                      <span className="text-white font-bold text-sm">
                        {member.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  </div>
                  
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-sm font-semibold text-gray-900 group-hover:text-cyan-600 transition-colors mb-1 line-clamp-1">
                        {member.name}
                      </h3>
                      <p className="text-cyan-600 font-medium mb-2 text-xs">{member.role}</p>
                      <p className="text-xs text-gray-600 mb-2 line-clamp-2 leading-tight">{member.expertise}</p>
                    </div>
                    <div className="mt-auto">
                      <div className="inline-flex items-center px-2 py-1 bg-gradient-to-r from-cyan-100 to-blue-100 rounded-full">
                        <span className="text-xs text-cyan-700 font-medium">{member.experience}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-white relative overflow-hidden">
        <div className="container-custom py-16 md:py-20 relative">
          <div className="mx-auto max-w-4xl text-center">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-800 mb-4">
              Ready to Transform Your
              <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent"> Digital Future?</span>
            </h2>
            <p className="text-base lg:text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Partner with us to leverage cutting-edge technology solutions that drive innovation and accelerate your business growth.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link 
                href="/contact" 
                className="group inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg hover:from-cyan-600 hover:to-blue-700 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Start Your Project
                <ArrowRightIcon className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link 
                href="/solutions" 
                className="inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-cyan-600 border-2 border-cyan-400 rounded-lg hover:bg-cyan-50 transition-all duration-300"
              >
                Explore Solutions
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}