'use client';

import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { Bars3Icon, XMarkIcon, ChevronDownIcon, ArrowRightIcon } from '@heroicons/react/24/outline';

const navigation = [
  { name: 'Home', href: '/' },
  
  { name: 'About Us', href: '/about' },
  { name: 'Our Services', href: '/services' },
  { 
    name: 'Projects', 
    href: '#',
    dropdown: [
      { name: 'IT Solutions', href: '/solutions' },
      { name: 'Research & Development', href: '/research' }
    ]
  },
  { name: 'Our Work', href: '/work' },
  { name: 'Career', href: '/career' },
  { name: 'Contact', href: '/contact' },
];

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [mobileDropdownOpen, setMobileDropdownOpen] = useState(false);
  const pathname = usePathname();
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const isActiveDropdownItem = (items: any[]) => {
    return items.some(item => pathname === item.href);
  };

  return (
    <header className="bg-white/95 backdrop-blur-md border-b border-gray-200/60 sticky top-0 z-50 shadow-sm transition-all duration-300">
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" aria-label="Global">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-3 group">
              <Image
                src="/logo.png"
                alt="NexyraTech Solution"
                width={50}
                height={50}
                className="w-20 h-20 group-hover:scale-105 transition-transform duration-300"
              />
              <span className="hidden sm:block text-lg font-bold">
                <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
                  
                </span>
                <span className="text-gray-800 ml-1"></span>
              </span>
            </Link>
          </div>
          
          {/* Desktop navigation */}
          <div className="hidden lg:flex lg:items-center lg:space-x-8">
            {navigation.map((item) => (
              <div key={item.name} className="relative group" ref={item.dropdown ? dropdownRef : undefined}>
                {item.dropdown ? (
                  <>
                    <button
                      className={`flex items-center text-sm font-medium transition-all duration-300 px-3 py-2 rounded-lg hover:bg-gray-50 group ${
                        isActiveDropdownItem(item.dropdown)
                          ? 'text-cyan-600 bg-cyan-50'
                          : 'text-gray-700 hover:text-cyan-600'
                      }`}
                      onClick={() => setDropdownOpen(!dropdownOpen)}
                      onMouseEnter={() => setDropdownOpen(true)}
                    >
                      {item.name}
                      <ChevronDownIcon className={`ml-1 h-4 w-4 transition-transform duration-300 ${
                        dropdownOpen ? 'rotate-180' : ''
                      }`} />
                    </button>
                    
                    {/* Enhanced Dropdown Menu */}
                    {dropdownOpen && (
                      <div 
                        className="absolute left-0 mt-2 w-64 bg-white/95 backdrop-blur-xl border border-gray-200/60 rounded-xl shadow-xl z-50 transform animate-in fade-in slide-in-from-top-2 duration-200"
                        onMouseLeave={() => setDropdownOpen(false)}
                      >
                        <div className="py-2">
                          {item.dropdown.map((dropdownItem) => (
                            <Link
                              key={dropdownItem.name}
                              href={dropdownItem.href}
                              className={`block px-4 py-3 text-sm transition-all duration-200 hover:bg-gradient-to-r hover:from-cyan-50 hover:to-blue-50 ${
                                pathname === dropdownItem.href
                                  ? 'text-cyan-600 bg-cyan-50 border-l-2 border-cyan-400'
                                  : 'text-gray-700 hover:text-cyan-600'
                              }`}
                              onClick={() => setDropdownOpen(false)}
                            >
                              {dropdownItem.name}
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <Link
                    href={item.href}
                    className={`relative text-sm font-medium transition-all duration-300 px-3 py-2 rounded-lg hover:bg-gray-50 group ${
                      pathname === item.href
                        ? 'text-cyan-600 bg-cyan-50'
                        : 'text-gray-700 hover:text-cyan-600'
                    }`}
                  >
                    {item.name}
                    <span className="absolute inset-x-0 -bottom-1 h-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
                  </Link>
                )}
              </div>
            ))}
          </div>
          
          {/* CTA Button & Mobile Menu */}
          <div className="flex items-center space-x-4">
            <Link
              href="/contact"
              className="hidden md:inline-flex items-center px-3 py-1.5 text-sm font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg hover:from-cyan-600 hover:to-blue-700 transform hover:scale-[1.02] transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              Get Started
              <ArrowRightIcon className="ml-2 h-4 w-4" />
            </Link>            
            {/* Mobile menu button */}
            <button
              type="button"
              className="lg:hidden p-2 inline-flex items-center justify-center rounded-lg text-gray-700 hover:text-cyan-600 hover:bg-gray-50 transition-all duration-300"
              onClick={() => setMobileMenuOpen(true)}
            >
              <span className="sr-only">Open main menu</span>
              <Bars3Icon className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>        </div>
      </nav>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden" role="dialog" aria-modal="true">
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)}></div>
          <div className="fixed inset-y-0 right-0 z-50 w-full max-w-sm overflow-y-auto bg-white/95 backdrop-blur-xl px-6 py-6 border-l border-gray-200/60 shadow-2xl">
            <div className="flex items-center justify-between mb-8">
              <Link href="/" className="flex items-center space-x-2" onClick={() => setMobileMenuOpen(false)}>
                <Image
                  src="/logo.png"
                  alt="NexyraTech Solution"
                  width={40}
                  height={40}
                  className="w-10 h-10"
                />
                <span className="text-lg font-bold">
                  <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
                    NexyraTech
                  </span>
                  <span className="text-gray-800 ml-1">Solution</span>
                </span>
              </Link>
              <button
                type="button"
                className="p-2 rounded-lg text-gray-700 hover:text-cyan-600 hover:bg-gray-50 transition-all duration-300"
                onClick={() => setMobileMenuOpen(false)}
              >
                <span className="sr-only">Close menu</span>
                <XMarkIcon className="h-6 w-6" aria-hidden="true" />
              </button>
            </div>
            <div className="flow-root">
              <div className="space-y-2">
                {navigation.map((item) => (
                  <div key={item.name}>
                    {item.dropdown ? (
                      <>
                        <button
                          className={`flex items-center justify-between w-full rounded-xl px-4 py-3 text-base font-medium transition-all duration-300 ${
                            isActiveDropdownItem(item.dropdown)
                              ? 'text-cyan-600 bg-gradient-to-r from-cyan-50 to-blue-50'
                              : 'text-gray-700 hover:text-cyan-600 hover:bg-gray-50'
                          }`}
                          onClick={() => setMobileDropdownOpen(!mobileDropdownOpen)}
                        >
                          {item.name}
                          <ChevronDownIcon className={`h-5 w-5 transition-transform duration-300 ${
                            mobileDropdownOpen ? 'rotate-180' : ''
                          }`} />
                        </button>
                        {mobileDropdownOpen && (
                          <div className="ml-4 mt-2 space-y-1">
                            {item.dropdown.map((dropdownItem) => (
                              <Link
                                key={dropdownItem.name}
                                href={dropdownItem.href}
                                className={`block rounded-lg px-4 py-2 text-sm font-medium transition-all duration-300 ${
                                  pathname === dropdownItem.href
                                    ? 'text-cyan-600 bg-cyan-50 border-l-2 border-cyan-400'
                                    : 'text-gray-600 hover:text-cyan-600 hover:bg-gray-50'
                                }`}
                                onClick={() => setMobileMenuOpen(false)}
                              >
                                {dropdownItem.name}
                              </Link>
                            ))}
                          </div>
                        )}
                      </>
                    ) : (
                      <Link
                        href={item.href}
                        className={`block rounded-xl px-4 py-3 text-base font-medium transition-all duration-300 ${
                          pathname === item.href
                            ? 'text-cyan-600 bg-gradient-to-r from-cyan-50 to-blue-50'
                            : 'text-gray-700 hover:text-cyan-600 hover:bg-gray-50'
                        }`}
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        {item.name}
                      </Link>
                    )}
                  </div>
                ))}
                
                {/* Mobile CTA Button */}
                <div className="pt-4 mt-6 border-t border-gray-200">
                  <Link
                    href="/contact"
                    className="flex items-center justify-center w-full px-4 py-3 text-base font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all duration-300 shadow-lg"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Get Started
                    <ArrowRightIcon className="ml-2 h-5 w-5" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}