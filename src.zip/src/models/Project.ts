import mongoose, { Document, Schema } from 'mongoose';

export interface IProject extends Document {
  title: string;
  description: string;
  detailedDescription: string;
  technologies: string[];
  category: string;
  subcategory: string;
  status: 'completed' | 'ongoing' | 'planned';
  startDate: Date;
  endDate?: Date;
  images: string[];
  demoUrl?: string;
  githubUrl?: string;
  externalUrl?: string;
  featured: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const ProjectSchema: Schema = new Schema(
  {
    title: {
      type: String,
      required: [true, 'Project title is required'],
      trim: true,
    },
    description: {
      type: String,
      required: [true, 'Project description is required'],
      maxlength: [200, 'Description must be less than 200 characters'],
    },
    detailedDescription: {
      type: String,
      required: [true, 'Detailed description is required'],
    },
    technologies: {
      type: [String],
      required: [true, 'Technologies are required'],
      validate: {
        validator: (v: string[]) => v && v.length > 0,
        message: 'At least one technology is required',
      },
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      enum: ['it-solutions', 'research-development'],
    },
    subcategory: {
      type: String,
      required: [true, 'Subcategory is required'],
      enum: ['web-development', 'mobile-app', 'desktop-app', 'ai-ml', 'blockchain', 'iot', 'cybersecurity', 'cloud-solutions', 'system-integration', 'other'],
    },
    status: {
      type: String,
      enum: ['completed', 'ongoing', 'planned'],
      default: 'ongoing',
    },
    startDate: {
      type: Date,
      required: [true, 'Start date is required'],
    },
    endDate: {
      type: Date,
    },
    images: {
      type: [String],
      default: [],
    },
    demoUrl: {
      type: String,
      trim: true,
    },
    githubUrl: {
      type: String,
      trim: true,
    },
    externalUrl: {
      type: String,
      trim: true,
    },
    featured: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.models.Project || mongoose.model<IProject>('Project', ProjectSchema);